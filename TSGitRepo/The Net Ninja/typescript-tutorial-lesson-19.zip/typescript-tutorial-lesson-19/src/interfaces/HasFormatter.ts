export interface HasFormatter {
  format(): string;
}