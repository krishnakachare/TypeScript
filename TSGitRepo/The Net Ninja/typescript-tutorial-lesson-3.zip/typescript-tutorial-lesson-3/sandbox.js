var character = 'mario';
var age = 30;
var isBlackBelt = false;
// character = 20;
character = 'luigi';
// age = 'yoshi';
age = 40;
// isBlackBelt = 'yes';
isBlackBelt = true;
var area = function (diameter) {
    return diameter * Math.PI;
};
// console.log(area('hello'));
console.log(area(7.5));
