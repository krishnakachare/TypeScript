"use strict";
// some other ts file inside ./src folder
